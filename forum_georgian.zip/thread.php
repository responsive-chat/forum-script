<?php

include('common.php');

$page = getarg('page', 1);
$threadid = getarg('id');
$postid = getarg('pid');
$do = getarg('do', '');

if(islogged())
{
  if($threadid != NULL)
  {
    $threadid = intval($threadid);
    $query = mysql_query('SELECT * FROM `threads` WHERE `id` = \'' . $threadid . '\';');
    if(mysql_num_rows($query) > 0)
    {
      if($do == 'new')
      {
        echo theader($lang['newpost']);
        $query = mysql_query('SELECT `locked` FROM `threads` WHERE `id` = \'' . $threadid . '\';');
        $result = (bool)mysql_result($query, 0);
        if(!$result || checkmod())
          $locked = FALSE;
        else
          $locked = TRUE;

        if($locked)
        {
          echo '    <span>' . $lang['threadlocked'] . '</span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
        }
        else
        {
          if(isset($_POST['message']) && !empty($_POST['message']))
          {
            @mysql_query('UPDATE `threads` SET `lastpost` = \'' . time() . '\' WHERE `id` = \'' . $threadid . '\';');
            $query = mysql_query('INSERT INTO `posts` VALUES(\'0\', \'' . $threadid . '\', \'' . clean($_POST['message']) . '\', \'' . getid() . '\', \'' . time() . '\');');
            if(mysql_affected_rows() > 0)
            {
              $tmessage = bbcode(clean($_POST['message']));
              $tmessage = smile($tmessage);
              echo '    <span>' . $lang['postcreated'] . '</span><br />' . "\r\n";
              echo "    <span><b>" . $tmessage . "</b></span><br /><br />\r\n";
              echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;page=last">' . $lang['thread'] . '</a></span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
            }
            else
            {
              echo '    <span>' . $lang['newposterror'] . '</span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=new">' . $lang['back'] . '</a></span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
            }
          }
          else
          {
            echo '    <span>' . $lang['newpost'] . '</span><br /><br />' . "\r\n";
            echo '    <form method="post" action="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=new">' . "\r\n";
            echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
            echo '      <textarea name="message" maxlength="5000"></textarea><br />' . "\r\n";
            echo '      <input type="submit" value="' . $lang['postit'] . '" /><br /><br />' . "\r\n";
            echo '    </form>' . "\r\n";
            echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
            echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
          }
        }
      }
      elseif($do == 'lock')
      {
        if($threadid > 0 && checkmod())
        {
          $query = mysql_query('SELECT `locked` FROM `threads` WHERE `id` = \'' . $threadid . '\';');
          if(mysql_num_rows($query) > 0)
          {
            $locked = (bool)intval(mysql_result($query, 0));
            if($locked)
              @mysql_query('UPDATE `threads` SET `locked` = \'0\' WHERE `id` = \'' . $threadid . '\';');
            else
              @mysql_query('UPDATE `threads` SET `locked` = \'1\' WHERE `id` = \'' . $threadid . '\';');
          }
        }

        header('Location: ' . $s_siteurl . '/thread.php?lang=' . $language . '&id=' . $threadid);
      }
      elseif($do == 'pin')
      {
        if($threadid > 0 && checkmod())
        {
          $query = mysql_query('SELECT `pinned` FROM `threads` WHERE `id` = \'' . $threadid . '\';');
          if(mysql_num_rows($query) > 0)
          {
            $pinned = (bool)intval(mysql_result($query, 0));
            if($pinned)
              @mysql_query('UPDATE `threads` SET `pinned` = \'0\' WHERE `id` = \'' . $threadid . '\';');
            else
              @mysql_query('UPDATE `threads` SET `pinned` = \'1\' WHERE `id` = \'' . $threadid . '\';');
          }
        }

        header('Location: ' . $s_siteurl . '/thread.php?lang=' . $language . '&id=' . $threadid);
      }
      elseif($do == 'delete')
      {
        if($postid > 0 && checkmod())
        {
          $query = mysql_query('SELECT * FROM `posts` WHERE `id` = \'' . $postid . '\';');
          if(mysql_num_rows($query) > 0)
          {
            @mysql_query('DELETE FROM `posts` WHERE `id` = \'' . $postid . '\';');
          }
        }

        header('Location: ' . $s_siteurl . '/thread.php?lang=' . $language . '&id=' . $threadid);
      }
      elseif($do == 'edit')
      {
        $query = mysql_query('SELECT * FROM `posts` WHERE `id` = \'' . $postid . '\';');
        if(mysql_num_rows($query) > 0)
        {
          $result = mysql_fetch_array($query);
          if($result['poster'] == getid() || checkmod())
          {
            if(isset($_POST['message']) && !empty($_POST['message']))
            {
              $message = clean($message);
              @mysql_query('UPDATE `posts` SET `post` = \'' . $message . '\' WHERE `id` = \'' . $postid . '\';');
              header('Location: ' . $s_siteurl . '/thread.php?lang=' . $language . '&id=' . $threadid);
            }
            else
            {
              $message = str_replace('<br />', "\r\n", $result['post']);
              echo theader($lang['editpost']);
              echo '    <span>' . $lang['editpost'] . '</span><br /><br />' . "\r\n";
              echo '    <form method="post" action="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=edit&amp;pid=' . $postid . '">' . "\r\n";
              echo '      <span>' . $lang['message'] . '</span><br />' . "\r\n";
              echo '      <textarea name="message" maxlength="5000">' . $message . '</textarea><br />' . "\r\n";
              echo '      <input type="submit" value="' . $lang['edit'] . '" /><br />' . "\r\n";
              echo '    </form>' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
            }
          }
          else
            header('Location: ' . $s_siteurl . '/thread.php?lang=' . $language . '&id=' . $threadid);
        }
        else
          header('Location: ' . $s_siteurl . '/thread.php?lang=' . $language . '&id=' . $threadid);
      }
      else
      {
        $result = mysql_fetch_array($query);
        echo theader($lang['thread'] . ' / ' . $result['title']);

        $locked = (bool)intval($result['locked']);
        $pinned = (bool)intval($result['pinned']);

        $query = mysql_query('SELECT COUNT(*) FROM `posts` WHERE `thread` = \'' . $threadid . '\';');
        $nposts = mysql_result($query, 0);
        $ntpp = 9;
        $npages = ceil($nposts / $ntpp);

        if($page == 'last')
          $page = $npages;

        $page = intval($page);

        if($page > $npages && $page != 1)
          $page = $npages;

        if($page > 1)
          echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;page=1">' . $lang['firstpage'] . '</a></span><br />' . "\r\n";
        if($npages > 1 && $page < $npages)
          echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;page=' . $npages . '">' . $lang['lastpage'] . '</a></span><br />' . "\r\n";

        if(!$locked || checkmod())
        {
          echo '    <form method="post" action="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=new">' . "\r\n";
          echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
          echo '      <textarea name="message" maxlength="5000"></textarea><br />' . "\r\n";
          echo '      <input type="submit" value="' . $lang['postit'] . '" /><br />' . "\r\n";
          echo '    </form>' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=new">' . $lang['newpost'] . '</a></span><br />' . "\r\n";
        }

        if($pinned)
        {
          if(checkmod())
            echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=pin">' . $lang['unpin'] . '</a></span><br />' . "\r\n";
        }
        else
        {
          if(checkmod())
            echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=pin">' . $lang['pin'] . '</a></span><br />' . "\r\n";
        }

        if($locked)
        {
          if(checkmod())
            echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=lock">' . $lang['unlock'] . '</a></span><br />' . "\r\n";
        }
        else
        {
          if(checkmod())
            echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=lock">' . $lang['lock'] . '</a></span><br />' . "\r\n";
        }

        echo '    <div class="left">' . "\r\n";

        $limit = ($page - 1) * $ntpp;

        $query = mysql_query('SELECT * FROM `threads` WHERE `id` = \'' . $threadid . '\';');
        $result = mysql_fetch_array($query);
        $fmessage = bbcode($result['post']);
        $fmessage = smile($fmessage);
        $forumid = intval($result['forum']);
        echo '      <div class="post">' . "\r\n";
	     	echo '        <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . intval($result['poster']) . '">' . getusername(intval($result['poster'])) . '</a>: (' . date('d/m/Y, H:i:s', $result['date']) . ')</span><br />' . "\r\n";
        echo '        <span>' . $fmessage . '</span><br />' . "\r\n";
	      echo '      </div>' . "\r\n";

        $posts = mysql_query('SELECT * FROM `posts` WHERE `thread` = \'' . $threadid . '\' ORDER BY `date` ASC LIMIT ' . $limit . ', ' . $ntpp . ';');
        if($nposts > 0)
        {
          while($post = mysql_fetch_array($posts))
          {
            $ppid = $post['id'];
            $pid = $post['poster'];
            $puser = getusername($pid);
            $pmessage = bbcode($post['post']);
            $pmessage = smile($pmessage);
            $pdate = $post['date'];

            if($pid == getid() || checkmod())
              $edl = ' <a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=edit&amp;pid=' . $ppid . '">[E]</a>';
            else
              $edl = '';

            if(checkmod())
              $dll = ' | <a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;do=delete&amp;pid=' . $ppid . '">[D]</a>';
            else
              $dll = '';

            echo '      <div class="post">' . "\r\n";
	    		  echo '        <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $pid . '">' . $puser . '</a>: (' . date('d/m/Y, H:i:s', $pdate) . ')' . $edl . $dll . '</span><br />' . "\r\n";
            echo '        <span>' . $pmessage . '</span><br />' . "\r\n";
	    		  echo '      </div>' . "\r\n";
          }
        }

        if($page > 1)
        {
          $bp = $page - 1;
          $bl = '<a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;page=' . $bp . '">&lt; ' . $lang['backward'] . '</a>';
        }
        else
          $bl = '&lt; ' . $lang['backward'];

        if($page < $npages)
        {
          $fp = $page + 1;
          $fl = ' | <a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $threadid . '&amp;page=' . $fp . '">' . $lang['forward'] . ' &gt;</a>';
        }
        else
          $fl = ' | ' . $lang['forward'] . ' &gt;';

        echo '    </div>' . "\r\n";
        echo '    <span>' . $bl . $fl . '</span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '">' . $lang['threads'] . '</a></span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
      }
    }
    else
    {
      echo theader($lang['threads']);
      echo '    <span>' . $lang['threadnotexists'] . '</span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
    }

    echo tfooter();
  }
  else
  {
    header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
  }
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
