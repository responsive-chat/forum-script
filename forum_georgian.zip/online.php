<?php

include('common.php');

$page = getarg('page', 1);

if(islogged())
{
  echo theader($lang['whosonline']);
  echo '    <span>' . $lang['whosonline'] . '</span><br /><br />' . "\r\n";

  $query = mysql_query('SELECT COUNT(*) FROM `online`;');
  if(($nonl = intval(mysql_result($query, 0))) > 0)
  {
    $ntpp = 10;
    $npages = ceil($nonl / $ntpp);

    if($page == 'last')
      $page = $npages;

    $page = intval($page);
    if($page == 0)
      $page = 1;

    if($page > $npages && $page != 1)
      $page = $npages;

    if($page > 1)
      echo '    <span><a href="' . $s_siteurl . '/online.php?lang=' . $language . '&amp;page=1">' . $lang['firstpage'] . '</a></span><br />' . "\r\n";
    if($npages > 1 && $page < $npages)
      echo '    <span><a href="' . $s_siteurl . '/online.php?lang=' . $language . '&amp;page=' . $npages . '">' . $lang['lastpage'] . '</a></span><br />' . "\r\n";

    $limit = ($page - 1) * $ntpp;

    $ons = mysql_query('SELECT * FROM `online` ORDER BY `time` DESC LIMIT ' . $limit . ', ' . $ntpp . ';');
    if($nonl > 0)
    {
      echo '    <div class="left">' . "\r\n";
      while($on = mysql_fetch_array($ons))
      {
        $uid = $on['user'];
        if($uid == 0)
          $uusername = $lang['guest'];
        else
          $uusername = '<a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $uid . '">' . getusername($uid) . '</a>';
        $where = $on['where'];
        echo '      <div class="online">' . "\r\n";
        echo '        <span>' . $uusername . ' - ' . $where . '</span><br />' . "\r\n";
        echo '      </div>' . "\r\n";
      }
      echo '    </div>' . "\r\n";
    }

    if($page > 1)
    {
      $bp = $page - 1;
      $bl = '<a href="' . $s_siteurl . '/online.php?lang=' . $language . '&amp;page=' . $bp . '">&lt; ' . $lang['backward'] . '</a>';
    }
    else
      $bl = '&lt; ' . $lang['backward'];

    if($page < $npages)
    {
      $fp = $page + 1;
      $fl = ' | <a href="' . $s_siteurl . '/online.php?lang=' . $language . '&amp;page=' . $fp . '">' . $lang['forward'] . ' &gt;</a>';
    }
    else
      $fl = ' | ' . $lang['forward'] . ' &gt;';

    echo '    </div>' . "\r\n";
    echo '    <span>' . $bl . $fl . '</span><br />' . "\r\n";
  }
  else
  {
    echo '    <span>' . $lang['onlineparadox'] . '</span><br /><br />' . "\r\n";
  }

  echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
  echo tfooter();
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
