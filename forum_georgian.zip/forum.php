<?php

include('common.php');

$page = intval(getarg('page', 1));
$forumid = getarg('id');
$threadid = getarg('tid');
$do = getarg('do', '');

if(islogged())
{
  if($forumid != NULL)
  {
    $forumid = intval($forumid);
    $query = mysql_query('SELECT * FROM `forums` WHERE `id` = \'' . $forumid . '\';');
    if(mysql_num_rows($query) > 0)
    {
      if($do == 'new')
      {
        echo theader($lang['newthread']);
        if((isset($_POST['title']) && !empty($_POST['title'])) && (isset($_POST['message']) && !empty($_POST['message'])))
        {
          $ttitle = clean($_POST['title']);
          $tmessage = clean($_POST['message']);
          $query = mysql_query('SELECT * FROM `threads` WHERE `title` = \'' . $ttitle . '\';');
          if(mysql_num_rows($query) > 0)
          {
            echo '    <span>' . $lang['threadexists'] . '</span><br />' . "\r\n";
            echo '    <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=new">' . $lang['back'] . '</a></span><br />' . "\r\n";
            echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
          }
          else
          {
            $query = mysql_query('INSERT INTO `threads` VALUES(\'0\', \'' . $forumid . '\', \'' . $ttitle . '\', \'' . $tmessage . '\', \'' . getid() . '\', \'' . time() . '\', \'' . time() . '\', \'0\', \'0\');');
            if(mysql_affected_rows() > 0)
            {
              $tmessage = bbcode($tmessage);
              $tmessage = smile($tmessage);
              $query = mysql_query('SELECT `id` FROM `threads` WHERE `title` = \'' . $ttitle . '\' AND `poster` = \'' . getid() . '\';');
              $result = mysql_result($query, 0);
              echo '    <span>' . $lang['threadcreated'] . '</span><br />' . "\r\n";
              echo '    <span><b>' . $tmessage . '</b></span><br /><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $result . '">' . $lang['thread'] . '</a></span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
            }
            else
            {
              echo '    <span>' . $lang['newthreaderror'] . '</span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=new">' . $lang['back'] . '</a></span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
            }
          }
        }
        else
        {
          echo '    <span>' . $lang['newthread'] . '</span><br /><br />' . "\r\n";
          echo '    <form method="post" action="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=new">' . "\r\n";
          echo '      <span>' . $lang['title'] . ':</span><br />' . "\r\n";
          echo '      <input type="text" name="title" maxlength="30" /><br />' . "\r\n";
          echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
          echo '      <textarea name="message" maxlength="5000"></textarea><br />' . "\r\n";
          echo '      <input type="submit" value="' . $lang['create'] . '" /><br /><br />' . "\r\n";
          echo '    </form>' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
        }
      }
      elseif($do == 'delete')
      {
        if($threadid != NULL && checkmod())
        {
          $query = mysql_query('SELECT * FROM `threads` WHERE `id` = \'' . $threadid . '\';');
          if(mysql_num_rows($query) > 0)
          {
            @mysql_query('DELETE FROM `posts` WHERE `thread` = \'' . $threadid . '\';');
            @mysql_query('DELETE FROM `threads` WHERE `id` = \'' . $threadid . '\';');
          }
        }

        header('Location: ' . $s_siteurl . '/forum.php?lang=' . $language . '&id=' . $forumid);
      }
      elseif($do == 'edit')
      {
        $query = mysql_query('SELECT * FROM `threads` WHERE `id` = \'' . $threadid . '\';');
        if(mysql_num_rows($query) > 0)
        {
          $result = mysql_fetch_array($query);
          if(checkmod())
          {
            if(isset($_POST['title']) && !empty($_POST['title']) && isset($_POST['message']) && !empty($_POST['message']))
            {
              $title = clean($title);
              $message = clean($message);
              @mysql_query('UPDATE `threads` SET `title` = \'' . $title . '\', `post` = \'' . $message . '\' WHERE `id` = \'' . $threadid . '\';');
              header('Location: ' . $s_siteurl . '/forum.php?lang=' . $language . '&id=' . $forumid);
            }
            else
            {
              $title = $result['title'];
              $message = str_replace('<br />', "\r\n", $result['post']);
              echo theader($lang['editthread']);
              echo '    <span>' . $lang['editthread'] . '</span><br /><br />' . "\r\n";
              echo '    <form method="post" action="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=edit&amp;tid=' . $threadid . '">' . "\r\n";
              echo '      <span>' . $lang['title'] . ':</span><br />' . "\r\n";
              echo '      <input type="text" name="title" maxlength="30" value="' . $title . '" /><br />' . "\r\n";
              echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
              echo '      <textarea name="message" maxlength="5000">' . $message . '</textarea><br />' . "\r\n";
              echo '      <input type="submit" value="' . $lang['edit'] . '" /><br />' . "\r\n";
              echo '    </form>' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
              echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
            }
          }
          else
            header('Location: ' . $s_siteurl . '/forum.php?lang=' . $language . '&id=' . $forumid);
        }
        else
          header('Location: ' . $s_siteurl . '/forum.php?lang=' . $language . '&id=' . $forumid);
      }
      else
      {
        $result = mysql_fetch_array($query);
        echo theader($lang['forum'] . ' / ' . $result['title']);

        echo '    <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=new">' . $lang['newthread'] . '</a></span><br /><br />' . "\r\n";

        $query = mysql_query('SELECT COUNT(*) FROM `threads` WHERE `forum` = \'' . $forumid . '\';');
        if(intval(mysql_result($query, 0)) > 0)
        {
          echo '    <div class="left">' . "\r\n";

          $nthreads = mysql_result($query, 0);
          $ntpp = 10;
          $npages = ceil($nthreads / $ntpp);
          if($page > $npages && $page != 1)
            $page = $npages;

          $limit = ($page - 1) * $ntpp;

          $pinned = mysql_query('SELECT * FROM `threads` WHERE `forum` = \'' . $forumid . '\' AND `pinned` = \'1\' ORDER BY `lastpost` DESC;');
          if(mysql_num_rows($pinned) > 0)
          {
            while($pin = mysql_fetch_array($pinned))
            {
              $pid = $pin['id'];
              $ptitle = $pin['title'];
              $plocked = (bool)$pin['locked'];
              $puser = getusername($pin['poster']);
              $pdate = $pin['date'];
              $query = mysql_query('SELECT COUNT(*) FROM `posts` WHERE `thread` = \'' . $pid . '\';');
              $postsCount = intval(mysql_result($query, 0));
              if($postsCount > 0)
              {
                $query = mysql_query('SELECT `poster` FROM `posts` WHERE `thread` = \'' . $pid . '\' ORDER BY `date` DESC LIMIT 0, 1;');
                $result = intval(mysql_result($query, 0));
                $lastbyid = $result;
                $lastby = getusername($lastbyid);
              }
              else
              {
                $lastbyid = $pin['poster'];
                $lastby = $puser;
              }

              if($plocked)
                $lstext = '[X]';
              else
                $lstext = '';

              if(checkmod())
              {
                $edl = ' <a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=edit&amp;tid=' . $pid . '">[E]</a>';
                $dll = ' <a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=delete&amp;tid=' . $pid . '">[D]</a>';
              }
              else
              {
                $edl = '';
                $dll = '';
              }

              echo '      <div class="thread">' . "\r\n";
	      		  echo '        <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $pid . '">' . $ptitle . ' (' . $postsCount . ')[^]' . $lstext . '</a> / (' . date('d/m/Y', $pdate) . ', ' . $lang['bywho'] . ': <b><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $pin['poster'] . '">' . $puser . '</a></b>, ' . $lang['lastpost'] . ': <b><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $lastbyid . '">' . $lastby . '</a></b>) <a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $pid . '&amp;page=last">&gt;&gt;</a>' . $edl . $dll . '</span><br />' . "\r\n";
	      		  echo '      </div>' . "\r\n";
            }

            echo '      <br />' . "\r\n";
          }

          $threads = mysql_query('SELECT * FROM `threads` WHERE `forum` = \'' . $forumid . '\' AND `pinned` = \'0\' ORDER BY `lastpost` DESC LIMIT ' . $limit . ', ' . $ntpp . ';');

          while($thread = mysql_fetch_array($threads))
          {
            $tid = $thread['id'];
            $ttitle = $thread['title'];
            $tlocked = (bool)$thread['locked'];
            $tuser = getusername($thread['poster']);
            $tdate = $thread['date'];
            $query = mysql_query('SELECT COUNT(*) FROM `posts` WHERE `thread` = \'' . $tid . '\';');
            $postsCount = intval(mysql_result($query, 0));
            if($postsCount > 0)
            {
              $query = mysql_query('SELECT `poster` FROM `posts` WHERE `thread` = \'' . $tid . '\' ORDER BY `date` DESC LIMIT 0, 1;');
              $result = intval(mysql_result($query, 0));
              $lastbyid = $result;
              $lastby = getusername($lastbyid);
            }
            else
            {
              $lastbyid = $thread['poster'];
              $lastby = $tuser;
            }

            if($tlocked)
              $lstext = '[X]';
            else
              $lstext = '';

            if(checkmod())
            {
              $edl = ' <a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=edit&amp;tid=' . $tid . '">[E]</a>';
              $dll = ' <a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;do=delete&amp;tid=' . $tid . '">[D]</a>';
            }
            else
            {
              $edl = '';
              $dll = '';
            }

            echo '      <div class="thread">' . "\r\n";
	    		  echo '        <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $tid . '">' . $ttitle . ' (' . $postsCount . ')' . $lstext . '</a> / (' . date('d/m/Y', $tdate) . ', ' . $lang['bywho'] . ': <b><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $thread['poster'] . '">' . $tuser . '</a></b>, ' . $lang['lastpost'] . ': <b><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $lastbyid . '">' . $lastby . '</a></b>) <a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $tid . '&amp;page=last">&gt;&gt;</a>' . $edl . $dll . '</span><br />' . "\r\n";
	    		  echo '      </div>' . "\r\n";
          }

          if($page > 1)
          {
            $bp = $page - 1;
            $bl = '<a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;page=' . $bp . '">&lt; ' . $lang['backward'] . '</a>';
          }
          else
            $bl = '&lt; ' . $lang['backward'];

          if($page < $npages)
          {
            $fp = $page + 1;
            $fl = ' | <a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $forumid . '&amp;page=' . $fp . '">' . $lang['forward'] . ' &gt;</a>';
          }
          else
            $fl = ' | ' . $lang['forward'] . ' &gt;';

          echo '    </div>' . "\r\n";
          echo '    <span>' . $bl . $fl . '</span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
        }
        else
        {
          echo '    <span>' . $lang['nothreads'] . '</span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
        }
      }
    }
    else
    {
      echo theader($lang['forums']);
      echo '    <span>' . $lang['forumnotexists'] . '</span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
    }

    echo tfooter();
  }
  else
  {
    header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
  }
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
