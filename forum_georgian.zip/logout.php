<?php

include('common.php');

if(islogged())
{
  $u_username = NULL;
	$u_password = NULL;
	$_SESSION['username'] = NULL;
	$_SESSION['password'] = NULL;
	$_SESSION['time'] = NULL;
}

header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);

exit();

?>
