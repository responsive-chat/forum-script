<?php

include('common.php');

$do = getarg('do');
$what = getarg('what');
$id = getarg('id');
$page = getarg('page');

if(islogged())
{
  if($do == 'new')
  {
    if($what == 'forum')
    {
      if(isset($_POST['title']) && !empty($_POST['title']))
      {
        $title = clean($_POST['title']);
        $description = isset($_POST['description']) ? (empty($_POST['description']) ? '' : clean($_POST['description'])) : '';
        $query = mysql_query('SELECT `position` FROM `forums` ORDER BY `position` DESC LIMIT 1;');
        $position = intval(mysql_result($query, 0));
        @mysql_query('INSERT INTO `forums` VALUES(\'0\', \'' . $title . '\', \'' . $description . '\', \'' . $position . '\');');
        header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
      }
      else
      {
        echo theader($lang['newforum']);
        echo '    <form method="post" action="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=new&amp;what=forum">' . "\r\n";
        echo '      <span>' . $lang['title'] . ':</span><br />' . "\r\n";
        echo '      <input type="text" name="title" maxlength="50" /><br />' . "\r\n";
        echo '      <span>' . $lang['description'] . ':</span><br />' . "\r\n";
        echo '      <textarea name="description" maxlength="5000"></textarea><br />' . "\r\n";
        echo '      <input type="submit" value="' . $lang['create'] . '" /><br />' . "\r\n";
        echo '    </form>' . "\r\n";
      }
    }
    elseif($what == 'shoutbox')
    {
      if(isset($_POST['message']) && !empty($_POST['message']))
      {
        $message = clean($_POST['message']);
        @mysql_query('INSERT INTO `shoutbox` VALUES(\'0\', \'' . getid() . '\', \'' . $message . '\', \'' . time() . '\');');
        header('Location: ' . $s_siteurl . '/index.php?lang=' . $language . '&do=shoutbox&page=1');
      }
      else
      {
        echo theader($lang['shout']);
        echo '    <form method="post" action="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=new&amp;what=shoutbox">' . "\r\n";
        echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
        echo '      <textarea name="message" maxlength="5000"></textarea><br />' . "\r\n";
        echo '      <input type="submit" value="' . $lang['shout'] . '" /><br />' . "\r\n";
        echo '    </form>' . "\r\n";
      }
    }

    if($what == 'shoutbox')
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=shoutbox">' . $lang['back'] . '</a></span><br />' . "\r\n";
    echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
  }
  elseif($do == 'delete')
  {
    if($what == 'forum')
    {
      if($id != NULL && checkadmin())
      {
        $query = mysql_query('SELECT * FROM `forums` WHERE `id` = \'' . $id . '\';');
        if(mysql_num_rows($query) > 0)
        {
          $threads = mysql_query('SELECT `id` FROM `threads` WHERE `forum` = \'' . $id . '\';');
          if(mysql_num_rows($query) > 0)
          {
            while($thread = mysql_fetch_array($query))
            {
              @mysql_query('DELETE FROM `posts` WHERE `thread` = \'' . $thread['id'] . '\';');
              @mysql_query('DELETE FROM `threads` WHERE `id` = \'' . $thread['id'] . '\';');
            }
          }
          @mysql_query('DELETE FROM `forums` WHERE `id` = \'' . $id . '\';');
        }
      }

      header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
    }
    elseif($what == 'shoutbox')
    {
      if($id != NULL && checkmod())
      {
        if($id == 'all' && checkadmin())
        {
          @mysql_query('TRUNCATE TABLE `shoutbox`;');
        }
        else
        {
          $query = mysql_query('SELECT * FROM `shoutbox` WHERE `id` = \'' . $id . '\';');
          if(mysql_num_rows($query) > 0)
            @mysql_query('DELETE FROM `shoutbox` WHERE `id` = \'' . $id . '\';');
        }
      }

      header('Location: ' . $s_siteurl . '/index.php?lang=' . $language . '&do=shoutbox');
    }
  }
  elseif($do == 'edit')
  {
    if($what == 'forum')
    {
      $query = mysql_query('SELECT * FROM `forums` WHERE `id` = \'' . $id . '\';');
      if(mysql_num_rows($query) > 0)
      {
        $result = mysql_fetch_array($query);
        if(checkadmin())
        {
          $title = getarg('title');
          $description = getarg('description');
          if(isset($title) && !empty($title) && isset($description) && !empty($description))
          {
            $title = clean($title);
            $description = clean($description);
            @mysql_query('UPDATE `forums` SET `title` = \'' . $title . '\', `description` = \'' . $description . '\' WHERE `id` = \'' . $id . '\';');
            header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
          }
          else
          {
            $title = $result['title'];
            $description = str_replace('<br />', "\r\n", $result['description']);
            echo theader($lang['editforum']);
            echo '    <span>' . $lang['editforum'] . '</span><br /><br />' . "\r\n";
            echo '    <form method="post" action="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=edit&amp;what=forum&amp;id=' . $id . '">' . "\r\n";
            echo '      <span>' . $lang['title'] . ':</span><br />' . "\r\n";
            echo '      <input type="text" name="title" maxlength="30" value="' . $title . '" /><br />' . "\r\n";
            echo '      <span>' . $lang['description'] . ':</span><br />' . "\r\n";
            echo '      <textarea name="description" maxlength="100">' . $description . '</textarea><br />' . "\r\n";
            echo '      <input type="submit" value="' . $lang['edit'] . '" /><br />' . "\r\n";
            echo '    </form>' . "\r\n";
            echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
          }
        }
        else
          header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
      }
      else
        header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
    }
    elseif($what == 'shoutbox')
    {
      $query = mysql_query('SELECT * FROM `shoutbox` WHERE `id` = \'' . $id . '\';');
      if(mysql_num_rows($query) > 0)
      {
        $result = mysql_fetch_array($query);
        if(checkmod())
        {
		  $message = getarg('message');
          if(isset($message) && !empty($message))
          {
            $message = clean($message);
            @mysql_query('UPDATE `shoutbox` SET `message` = \'' . $message . '\' WHERE `id` = \'' . $id . '\';');
            header('Location: ' . $s_siteurl . '/index.php?lang=' . $language . '&do=shoutbox');
          }
          else
          {
            $message = str_replace('<br />', "\r\n", $result['message']);
            echo theader($lang['editshoutbox']);
            echo '    <span>' . $lang['editshoutbox'] . '</span><br /><br />' . "\r\n";
            echo '    <form method="post" action="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=edit&amp;what=shoutbox&amp;id=' . $id . '">' . "\r\n";
            echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
            echo '      <textarea name="message" maxlength="5000">' . $message . '</textarea><br />' . "\r\n";
            echo '      <input type="submit" value="' . $lang['edit'] . '" /><br />' . "\r\n";
            echo '    </form>' . "\r\n";
            echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=shoutbox">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
          }
        }
        else
          header('Location: ' . $s_siteurl . '/index.php?lang=' . $language . '&do=shoutbox');
      }
      else
        header('Location: ' . $s_siteurl . '/index.php?lang=' . $language . '&do=shoutbox');
    }
    else
    {
      header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
    }
  }
  elseif($do == 'shoutbox')
  {
    echo theader($lang['shoutbox']);
    echo '    <form method="post" action="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=new&amp;what=shoutbox">' . "\r\n";
    echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
    echo '      <textarea name="message" maxlength="5000"></textarea><br />' . "\r\n";
    echo '      <input type="submit" value="' . $lang['shout'] . '" /><br />' . "\r\n";
    echo '    </form>' . "\r\n";

    {
      $query = mysql_query('SELECT COUNT(*) FROM `shoutbox`;');
      if(($nshts = intval(mysql_result($query, 0))) > 0)
      {
        $ntpp = 10;
        $npages = ceil($nshts / $ntpp);

        if($page == 'last')
          $page = $npages;

        $page = intval($page);
        if($page == 0)
          $page = 1;

        if($page > $npages && $page != 1)
          $page = $npages;

        if($page > 1)
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=shoutbox&amp;page=1">' . $lang['firstpage'] . '</a></span><br />' . "\r\n";
        if($npages > 1 && $page < $npages)
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=shoutbox&amp;page=' . $npages . '">' . $lang['lastpage'] . '</a></span><br />' . "\r\n";

        $limit = ($page - 1) * $ntpp;

        $shts = mysql_query('SELECT * FROM `shoutbox` ORDER BY `date` DESC LIMIT ' . $limit . ', ' . $ntpp . ';');
        if($nshts > 0)
        {
          echo '    <div class="left">' . "\r\n";
          while($shout = mysql_fetch_array($shts))
          {
            $id = $shout['id'];
            $user = getusername($shout['user']);
            $message = $shout['message'];
            
            $message = smile($message);
            $date = $shout['date'];

            if(checkmod())
            {
              $edl = ' <a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=edit&amp;what=shoutbox&amp;id=' . $id . '">[E]</a>';
              $dll = ' <a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=delete&amp;what=shoutbox&amp;id=' . $id . '">[D]</a>';
            }
            else
            {
              $edl = '';
              $dll = '';
            }

            echo '      <div class="shoutbox">' . "\r\n";
	  		    echo '        <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $shout['user'] . '">' . $user . '</a>: (' . date('d/m/Y, H:i:s', $date) . ')' . $edl . $dll . '</span><br />' . "\r\n";
            echo '        <span>' . $message . '</span><br />' . "\r\n";
            echo '      </div>' . "\r\n";
          }
	  		  echo '    </div>' . "\r\n";
        }

        if($page > 1)
        {
          $bp = $page - 1;
          $bl = '<a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=shoutbox&amp;page=' . $bp . '">&lt; ' . $lang['backward'] . '</a>';
        }
        else
          $bl = '&lt; ' . $lang['backward'];

        if($page < $npages)
        {
          $fp = $page + 1;
          $fl = ' | <a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=shoutbox&amp;page=' . $fp . '">' . $lang['forward'] . ' &gt;</a>';
        }
        else
          $fl = ' | ' . $lang['forward'] . ' &gt;';

        echo '    </div>' . "\r\n";
        echo '    <span>' . $bl . $fl . '</span><br />' . "\r\n";
      }
      else
      {
        echo '    <span>' . $lang['shoutboxempty'] . '</span><br /><br />' . "\r\n";
      }
    }

    if(checkadmin())
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=delete&amp;what=shoutbox&amp;id=all">' . $lang['deleteshoutbox'] . '</a></span><br />' . "\r\n";
    echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
  }
  else
  {
    echo theader($lang['main']);
    echo '    <span>' . $lang['welcome'] . ' ' . $s_sitename . ', ' . clean($u_username) . '</span><br />' . "\r\n";
    $query = mysql_query('SELECT COUNT(*) FROM `private` WHERE `to` = \'' . getid() . '\';');
    $pmall = intval(mysql_result($query, 0));
    $query = mysql_query('SELECT COUNT(*) FROM `private` WHERE `to` = \'' . getid() . '\' AND `read` = \'0\';');
    $pmnew = intval(mysql_result($query, 0));
    echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['pminbox'] . ' (' . $pmall . ' / ' . $pmnew . ')</a></span><br />' . "\r\n";
	  echo '    <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . getid() . '">' . $lang['myprofile'] . '</a></span><br />' . "\r\n";
    if($s_inviteonly)
	    echo '    <span><a href="' . $s_siteurl . '/invites.php?lang=' . $language . '">' . $lang['myinvites'] . '</a></span><br /><br />' . "\r\n";
    echo '    <div class="left">' . "\r\n";
    echo '      <div class="shoutbox">' . "\r\n";
    echo '        <div class="center"><span>' . $lang['shoutbox'] . '</span></div>' . "\r\n";
    $query = mysql_query('SELECT * FROM `shoutbox` ORDER BY `date` DESC LIMIT 0, 3;');
    while($shout = mysql_fetch_array($query))
    {
      $message = $shout['message'];
      
      $message = smile($message);
      echo '        <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $shout['user'] . '">' . getusername($shout['user']) . '</a>: ' . $message . '</span><br />' . "\r\n";
    }
    echo '        <div class="center"><span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=new&amp;what=shoutbox">' . $lang['shout'] . '</a> | <a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=shoutbox">' . $lang['more'] . '</a></span></div>' . "\r\n";
    echo '      </div>' . "\r\n";
    echo '    </div>' . "\r\n";
    echo '    <br />' . "\r\n";
    listforums();
    echo '    <br />' . "\r\n";
    echo '    <div class="left">' . "\r\n";
    echo '      <div class="latest">' . "\r\n";
    echo '        <div class="center"><span>' . $lang['randomthreads'] . '</span></div>' . "\r\n";
    $query = mysql_query('SELECT * FROM `threads` ORDER BY RAND() LIMIT 3;');
    while($thread = mysql_fetch_array($query))
      echo '        <span><a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $thread['id'] . '">' . $thread['title'] . '</a></span><br />' . "\r\n";
    echo '        <div class="center"><span>' . $lang['latest'] . '</span></div>' . "\r\n";
    echo '        <span>' . $lang['latestposts'] . ': ';
    $query = mysql_query('SELECT * FROM `threads` ORDER BY `lastpost` DESC LIMIT 0, 3;');
    while($thread = mysql_fetch_array($query))
      echo '          <a href="' . $s_siteurl . '/thread.php?lang=' . $language . '&amp;id=' . $thread['id'] . '&amp;page=last">' . $thread['title'] . '</a>, ';
    echo '        </span><br />' . "\r\n";
    echo '        <span>' . $lang['latestmembers'] . ': ';
    $query = mysql_query('SELECT * FROM `users` ORDER BY `date` DESC LIMIT 0, 3;');
    while($user = mysql_fetch_array($query))
      echo '          <a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $user['id'] . '">' . $user['username'] . '</a>, ';
    echo '        </span><br />' . "\r\n";
    echo '      </div>' . "\r\n";
    echo '    </div>' . "\r\n";
    echo '    <br />' . "\r\n";
    $query = @mysql_query('SELECT COUNT(*) FROM `online`;');
    $result = intval(@mysql_result($query, 0));
	  echo '    <span><a href="' . $s_siteurl . '/online.php?lang=' . $language . '">' . $lang['online'] . ' (' . $result . ')</a></span><br />' . "\r\n";
    $query = @mysql_query('SELECT COUNT(*) FROM `users`;');
    $result = intval(@mysql_result($query, 0));
	  echo '    <span><a href="' . $s_siteurl . '/users.php?lang=' . $language . '">' . $lang['lusers'] . ' (' . $result . ')</a></span><br />' . "\r\n";
	  echo '    <span><a href="' . $s_siteurl . '/statistics.php?lang=' . $language . '">' . $lang['statistics'] . '</a></span><br />' . "\r\n";
	  echo '    <span><a href="' . $s_siteurl . '/logout.php?lang=' . $language . '">' . $lang['logout'] . '</a></span><br /><br />' . "\r\n";
  }
}
else
{
  echo theader($lang['main']);
  echo '    <span>' . $lang['welcome'] . ' ' . $s_sitename . ' :)</span><br />' . "\r\n";
	echo '    <span>' . $lang['mustlogin'] . '</span><br /><br />' . "\r\n";
	echo tloginbox();
	echo '    <br />' . "\r\n";
  if($s_inviteonly)
	  echo '    <span>' . $lang['inviteonly'] . '</span><br />' . "\r\n";
	echo '    <span><a href="' . $s_siteurl . '/register.php?lang=' . $language . '">' . $lang['register'] . '</a></span><br /><br />' . "\r\n";
}

echo tfooter();
exit();

?>
