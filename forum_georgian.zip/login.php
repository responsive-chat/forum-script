<?php

include('common.php');

echo theader($lang['login']);

if(getarg('username') != NULL && getarg('password') != NULL)
{
  if(checkpassword(getarg('username'), getarg('password')))
	{
	  $_SESSION['username'] = getarg('username');
	  $_SESSION['password'] = getarg('password');
	  $_SESSION['time'] = clean(time());

    $useragent = trim(clean($_SERVER['HTTP_USER_AGENT']));
    $userip = isset($_SERVER['X_FORWARDED_FOR']) ? (empty($_SERVER['X_FORWARDED_FOR']) ? trim(clean($_SERVER['REMOTE_ADDR'])) : trim(clean($_SERVER['X_FORWARDED_FOR']))) : trim(clean($_SERVER['REMOTE_ADDR']));
    @mysql_query('UPDATE `users` SET `useragent` = \'' . $useragent . '\', `userip` = \'' . $userip . '\' WHERE `id` = \'' . getid(getarg('username')) . '\';');

		echo '    <span>' . $lang['loggedin'] . '</span><br /><br />' . "\r\n";
		echo '    <span>' . $lang['bookmarkthis'] . '</span><br />' . "\r\n";
		echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['continue'] . '</a></span><br />' . "\r\n";
	}
	else
	{
		echo '    <span>' . $lang['notloggedin'] . '</span><br />' . "\r\n";
		echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
	}
}
else
{
  echo '    <span>' . $lang['noinputdata'] . '</span><br />' . "\r\n";
  echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
}

echo tfooter();
exit();

?>
