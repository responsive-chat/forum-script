<?php

function getcode()
{
  global $s_sitename, $s_siteurl;
  $code = md5(uniqid(rand(), TRUE) . time() . md5($s_sitename . $s_siteurl) . date('d/m/y', time()));
  return substr($code, 0, 15);
}

function checkusername($username)
{
  $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($username) . '\';');
  return (bool)(mysql_num_rows($query) > 0);
}

function checkpassword($username, $password)
{
  $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($username) . '\' AND `password` = \'' . clean(md5(md5($password))) . '\' AND `approved` = \'1\';');
  return (bool)(mysql_num_rows($query) > 0);
}

function checkemail($email)
{
  if(@eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email))
  {
	  return TRUE;
	}
	else
	{
	  return FALSE;
	}
}

function checkinvite($code)
{
  $query = mysql_query('SELECT * FROM `invites` WHERE `code` = \'' . clean($code) . '\';');
  return (bool)(mysql_num_rows($query) > 0);
}

function addinvite($username)
{
  if(checkusername($username))
  {
    $invite = getcode();
    mysql_query('INSERT INTO `invites` VALUES(\'0\', \'' . getid($username) . '\', \'' . $invite . '\');');
    if(mysql_affected_rows() > 0)
      return $invite;
    else
      return NULL;
  }
  else
  {
    return NULL;
  }
}

function removeinvite($code)
{
  $query = mysql_query('SELECT * FROM `invites` WHERE `code` = \'' . clean($code) . '\';');
	if(mysql_num_rows($query) > 0)
	{
	  @mysql_query('DELETE FROM `invites` WHERE `code` = \'' . clean($code) . '\';');
  }
	
	return;
}

function checkadmin($username = NULL)
{
  if($username == NULL)
  {
    global $u_username;
    if(checkusername($u_username))
    {
      $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($u_username) . '\';');
      $result = mysql_fetch_array($query);
      return (bool)($result['status'] >= 3);
    }
    else
    {
      return FALSE;
    }
  }
  else
  {
    if(checkusername($username))
    {
      $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($username) . '\';');
      $result = mysql_fetch_array($query);
      return (bool)($result['status'] >= 3);
    }
    else
    {
      return FALSE;
    }
  }
}

function checkmod($username = NULL)
{
  if($username == NULL)
  {
    global $u_username;
    if(checkusername($u_username))
    {
      $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($u_username) . '\';');
      $result = mysql_fetch_array($query);
      return (bool)($result['status'] >= 2);
    }
    else
    {
      return FALSE;
    }
  }
  else
  {
    if(checkusername($username))
    {
      $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($username) . '\';');
      $result = mysql_fetch_array($query);
      return (bool)($result['status'] >= 2);
    }
    else
    {
      return FALSE;
    }
  }
}

function checkbanned($username = NULL)
{
  $time = time();
  $timeout = $time - 120960;
  @mysql_query('UPDATE `users` SET `banned` = \'0\', `bantime` = \'0\' WHERE `bantime` < \'' . $timeout . '\';');

  if($username != NULL)
  {
    if(checkusername($username))
    {
      $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($username) . '\';');
      $result = mysql_fetch_array($query);
      return (bool)($result['banned'] > 0);
    }
    else
    {
      return FALSE;
    }
  }
  else
  {
    $useragent = isset($_SERVER['HTTP_USER_AGENT']) ? clean($_SERVER['HTTP_USER_AGENT']) : 'unknown';
    $userip = isset($_SERVER['X_FORWARDED_FOR']) ? clean($_SERVER['X_FORWARDED_FOR']) : (isset($_SERVER['REMOTE_ADDR']) ? clean($_SERVER['REMOTE_ADDR']) : 'unknown');
    $query = mysql_query('SELECT * FROM `banned` WHERE `useragent` = \'' . $useragent . '\' AND `userip` = \'' . $userip . '\';');
    return (bool)(mysql_num_rows($query) > 0);
  }
}

function adduser($username, $password, $email)
{
  if(!checkusername($username))
  {
    $useragent = trim(clean($_SERVER['HTTP_USER_AGENT']));
    $userip = isset($_SERVER['X_FORWARDED_FOR']) ? (empty($_SERVER['X_FORWARDED_FOR']) ? trim(clean($_SERVER['REMOTE_ADDR'])) : trim(clean($_SERVER['X_FORWARDED_FOR']))) : trim(clean($_SERVER['REMOTE_ADDR']));
    $query = mysql_query('INSERT INTO `users` VALUES (\'0\', \'' . clean($username) . '\', \'' . clean(md5(md5($password))) . '\', \'' . clean($email) . '\', \'' . time() . '\', \'' . $useragent . '\', \'' . $userip . '\', \'0\', \'0\', \'1\', \'0\');');
    if(mysql_affected_rows() > 0)
      return TRUE;
    else
      return FALSE;
  }
  else
  {
    return FALSE;
  }
}

function removeuser($username)
{
  if(checkusername($username))
  {
    $query = mysql_query('DELETE FROM `users` WHERE username = \'' . clean($username) . '\';');
    if(mysql_affected_rows() > 0)
      return TRUE;
    else
      return FALSE;
  }
  else
  {
    return FALSE;
  }
}

function islogged()
{
  $u_username = isset($_SESSION['username']) ? (empty($_SESSION['username']) ? NULL : clean($_SESSION['username'])) : NULL;
  $u_password = isset($_SESSION['password']) ? (empty($_SESSION['password']) ? NULL : clean($_SESSION['password'])) : NULL;

  if($u_username == NULL && $u_password == NULL)
	{
	  return FALSE;
	}
	else
	{
	  if(checkpassword($u_username, $u_password))
		{
		  return TRUE;
		}
		else
		{
		  return FALSE;
		}
	}
}

function getid($giusername = NULL)
{
  if($giusername == NULL)
	{
    $u_username = isset($_SESSION['username']) ? (empty($_SESSION['username']) ? NULL : $_SESSION['username']) : NULL;;
	  if($u_username != NULL && checkusername($u_username))
	  {
	    $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($u_username) . '\';');
	  	$result = mysql_fetch_array($query);
  		return intval($result['id']);
	  }
  	else
  	{
  	  return NULL;
  	}
	}
	else
	{
	  if($giusername != NULL && checkusername($giusername))
	  {
	    $query = mysql_query('SELECT * FROM `users` WHERE `username` = \'' . clean($giusername) . '\';');
	  	$result = mysql_fetch_array($query);
  		return intval($result['id']);
	  }
  	else
  	{
  	  return NULL;
  	}
	}
}

function getusername($id)
{
  if($id > 0)
  {
    $query = mysql_query('SELECT * FROM `users` WHERE `id` = \'' . intval(clean($id)) . '\';');
    if(mysql_num_rows($query) > 0)
    {
      $result = mysql_fetch_array($query);
      return $result['username'];
    }
    else
    {
      return NULL;
    }
  }
  else
    return NULL;
}

function formatstatus($sid, $uid = NULL)
{
  global $lang;
  
  if($uid == 1)
    return $lang['status']['owner'];
  
  if($sid >= 3)
    return $lang['status']['admin'];
  elseif($sid == 2)
    return $lang['status']['mod'];
  else
    return $lang['status']['user'];
}

function setonline($user, $where)
{
  $user = intval($user);
  if($user > 0)
  {
    $query = mysql_query('SELECT * FROM `online` WHERE `user` = \'' . $user . '\';');
    if(mysql_num_rows($query) > 0)
    {
      @mysql_query('UPDATE `online` SET `where` = \'' . $where . '\', `time` = \'' . time() . '\' WHERE `user` = \'' . $user . '\';');
      return;
    }
    else
    {
      @mysql_query('INSERT INTO `online` VALUES(\'0\', \'' . intval(clean($user)) . '\', \'' . clean($where) . '\', \'' . time() . '\');');
      return;
    }
  }
}

?>
