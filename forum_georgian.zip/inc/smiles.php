<?php

function smile($string)
{
  global $s_siteurl;
  $string = str_replace(':)', '<img src="' . $s_siteurl . '/smiles/smile.gif" alt=":)" />', $string);
  $string = str_replace(':(', '<img src="' . $s_siteurl . '/smiles/sad.gif" alt=":(" />', $string);
  $string = str_replace(';)', '<img src="' . $s_siteurl . '/smiles/wink.gif" alt=";)" />', $string);
  $string = str_replace(':D', '<img src="' . $s_siteurl . '/smiles/biggrin.gif" alt=":D" />', $string);
  $string = str_replace(':P', '<img src="' . $s_siteurl . '/smiles/tongue.gif" alt=":P" />', $string);
  $string = str_replace('xD', '<img src="' . $s_siteurl . '/smiles/laugh.gif" alt="xD" />', $string);
  $string = str_replace(':d', '<img src="' . $s_siteurl . '/smiles/biggrin.gif" alt=":D" />', $string);
  $string = str_replace(':p', '<img src="' . $s_siteurl . '/smiles/tongue.gif" alt=":P" />', $string);
  $string = str_replace('xd', '<img src="' . $s_siteurl . '/smiles/laugh.gif" alt="xD" />', $string);
  $string = str_replace('Xd', '<img src="' . $s_siteurl . '/smiles/laugh.gif" alt="xD" />', $string);
  $string = str_replace('XD', '<img src="' . $s_siteurl . '/smiles/laugh.gif" alt="xD" />', $string);
  $string = str_replace('xĐ', '<img src="' . $s_siteurl . '/smiles/xj.gif" alt="xĐ" />', $string);
  $string = str_replace('xđ', '<img src="' . $s_siteurl . '/smiles/xj.gif" alt="xĐ" />', $string);
  $string = str_replace('Xđ', '<img src="' . $s_siteurl . '/smiles/xj.gif" alt="xĐ" />', $string);
  $string = str_replace('XĐ', '<img src="' . $s_siteurl . '/smiles/xj.gif" alt="xĐ" />', $string);
  return $string;
}

?>
