<?php

include('common.php');

if(!islogged())
{
  echo theader($lang['lostpassword']);

  if(getarg('code') != NULL)
  {
    $query = mysql_query('SELECT * FROM `recover` WHERE `code` = \'' . getarg('code') . '\';');
    if(mysql_num_rows($query) > 0)
    {
      $newpassword = clean(getcode());
      $result = mysql_fetch_array($query);
      $userid = intval($result['user']);
      $query = mysql_query('SELECT * FROM `users` WHERE `id` = \'' . $userid . '\';');
      $result = mysql_fetch_array($query);
      $useremail = $result['email'];
      $query = mysql_query('UPDATE `users` SET `password` = \'' . md5(md5($newpassword)) . '\' WHERE `id` = \'' . $userid . '\';');
      if(mysql_affected_rows() > 0)
      {
	  	  $msub = $lang['lostpassword'];
	  	  $mmsg = $lang['yournewpassword'] . ' ' . $newpassword . "\r\n" . $s_siteurl . '/' . "\r\n";
	  	  @mail($useremail, $msub, $mmsg, "From: $s_email <$s_email>\r\n");
        @mysql_query('DELETE FROM `recover` WHERE `code` = \'' . getarg('code') . '\';');
        echo '    <span>' . $lang['newpasswordsent'] . '</span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
      }
      else
      {
        echo '    <span>' . $lang['recoveryerror'] . '</span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/recover.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
      }
    }
    else
    {
      echo '    <span>' . $lang['wrongrecoverycode'] . '</span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
    }
  }
  else
  {
    if(isset($_POST['email']) && !empty($_POST['email']))
    {
      $email = trim($_POST['email']);
      $query = mysql_query('SELECT * FROM `users` WHERE `email` = \'' . $email . '\';');
      if(mysql_num_rows($query) > 0)
      {
        $result = mysql_fetch_array($query);
        $userid = intval($result['id']);
        $query = mysql_query('SELECT * FROM `recover` WHERE `user` = \'' . $userid . '\';');
        if(mysql_num_rows($query) > 0)
        {
          $result = mysql_fetch_array($query);
          $code = trim($result['code']);
		      $msub = $lang['lostpassword'];
		      $mmsg = $lang['torecover'] . "\r\n" . $s_siteurl . '/recover.php?lang=' . $language . '&code=' . $code . "\r\n";
		      @mail($email, $msub, $mmsg, "From: $s_email <$s_email>\r\n");
          echo '    <span>' . $lang['recoversent'] . '</span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
        }
        else
        {
          $code = clean(getcode());
          @mysql_query('INSERT INTO `recover` VALUES(\'0\', \'' . $userid . '\', \'' . $code . '\', \'' . time() . '\');');
	  	    $msub = $lang['lostpassword'];
	  	    $mmsg = $lang['torecover'] . "\r\n" . $s_siteurl . '/recover.php?lang=' . $language . '&code=' . $code . "\r\n";
	  	    @mail($email, $msub, $mmsg, "From: $s_email <$s_email>\r\n");
          echo '    <span>' . $lang['recoversent'] . '</span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
        }
      }
      else
      {
        echo '    <span>' . $lang['emailnotinuse'] . '</span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/recover.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
      }
    }
    else
    {
	    echo '    <span>' . $lang['enteremail'] . '</span><br /><br />' . "\r\n";
  	  echo trecoverbox();
  	  echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
    }
  }

  echo tfooter();
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
