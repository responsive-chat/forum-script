<?php

include('common.php');

if(islogged())
{
  $do = getarg('do');
  $pm = getarg('pm');
  $id = getarg('id');
  $page = getarg('page', 1);

  if($do == 'read')
  {
    echo theader($lang['pmread']);
    $id = intval($id);
    $query = mysql_query('SELECT * FROM `private` WHERE `to` = \'' . getid() . '\' AND `id` = \'' . $id . '\';');
    if(mysql_num_rows($query) > 0)
    {
      @mysql_query('UPDATE `private` SET `read` = \'1\' WHERE `to` = \'' . getid() . '\' AND `id` = \'' . $id . '\';');
      $pm = mysql_fetch_array($query);
      $from = getusername($pm['from']);
      $date = $pm['date'];
      $message = $pm['message'];
      $message = bbcode($message);
      $message = smile($message);
      echo '    <div class="left">' . "\r\n";
      echo '      <div class="pm">' . "\r\n";
	    echo '        <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $pm['from'] . '">' . $from . '</a>: (' . date('d/m/Y, H:i:s', $date) . ')</span><br />' . "\r\n";
      echo '        <span>' . $message . '</span><br />' . "\r\n";
	    echo '      </div>' . "\r\n";
      echo '    </div>' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=write&amp;id=' . $id . '">' . $lang['pmreply'] . '</a> | <a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=delete&amp;id=' . $id . '">' . $lang['pmdelete'] . '</a></span><br />';
      echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
    }
    else
    {
        echo '    <span>' . $lang['pmnotexists'] . '</span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
    }
  }
  elseif($do == 'write')
  {
    echo theader($lang['pmnew']);
    if($id == NULL)
    {
      if(isset($_POST['to']) && !empty($_POST['to']) && isset($_POST['message']) && !empty($_POST['message']))
      {
        $to = clean($_POST['to']);
        $message = clean($_POST['message']);
        $tid = @mysql_query('SELECT `id` FROM `users` WHERE `username` = \'' . $to . '\';');
        $tid = intval(@mysql_result($tid, 0));
        if($tid > 0)
        {
          @mysql_query('INSERT INTO `private` VALUES(\'0\', \'' . getid() . '\', \'' . $tid . '\', \'' . time() . '\', \'' . $message . '\', \'0\');');
          $message = bbcode($message);
          $message = smile($message);
          echo '    <span>' . $lang['pmsent'] . '</span><br />' . "\r\n";
          echo '    <span>' . $message . '</span><br /><br />' . "\r\n";
        }
        else
        {
          echo '    <span>' . $lang['usernotexists'] . '</span><br />' . "\r\n";
        }
      }
      else
      {
        echo '    <form method="post" action="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=write">' . "\r\n";
        echo '      <span>' . $lang['pmto'] . ':</span><br />' . "\r\n";
        echo '      <input type="text" name="to" value="' . getarg('to', '') . '" /><br />' . "\r\n";
        echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
        echo '      <textarea name="message" maxlength="5000"></textarea><br />' . "\r\n";
        echo '      <input type="submit" value="' . $lang['send'] . '" /> <input type="reset" value="' . $lang['reset'] . '" /><br />' . "\r\n";
        echo '    </form>' . "\r\n";
      }

      echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
    }
    else
    {
      $id = intval($id);
      $to = mysql_query('SELECT `from` FROM `private` WHERE `id` = \'' . $id . '\' AND `to` = \'' . getid() . '\';');
      $to = intval(mysql_result($to, 0));
      if($to > 0)
      {
        if(isset($_POST['message']) && !empty($_POST['message']))
        {
          $message = clean($_POST['message']);
          @mysql_query('INSERT INTO `private` VALUES(\'0\', \'' . getid() . '\', \'' . $to . '\', \'' . time() . '\', \'' . $message . '\', \'0\');');
          $message = bbcode($message);
          $message = smile($message);
          echo '    <span>' . $lang['pmsent'] . '</span><br />' . "\r\n";
          echo '    <span>' . $message . '</span><br /><br />' . "\r\n";
        }
        else
        {
          echo '    <form method="post" action="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=write&amp;id=' . $id . '">' . "\r\n";
          echo '      <span>' . $lang['message'] . ':</span><br />' . "\r\n";
          echo '      <textarea name="message" maxlength="5000"></textarea><br />' . "\r\n";
          echo '      <input type="submit" value="' . $lang['send'] . '" /> <input type="reset" value="' . $lang['reset'] . '" /><br />' . "\r\n";
          echo '    </form>' . "\r\n";
        }
      }
      else
      {
        echo '    <span>' . $lang['pmnotexists'] . '</span><br />' . "\r\n";
      }
      echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
    }
  }
  elseif($do == 'delete')
  {
    echo theader($lang['pmdelete']);
    if($id == 'all')
    {
      @mysql_query('DELETE FROM `private` WHERE `to` = \'' . getid() . '\' AND `read` = \'1\';');
      echo '    <span>' . $lang['pmdeleted'] . '</span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
    }
    else
    {
      $id = intval($id);
      $query = mysql_query('SELECT * FROM `private` WHERE `id` = \'' . $id . '\' AND `to` = \'' . getid() . '\';');
      if(mysql_num_rows($query) > 0)
      {
        @mysql_query('DELETE FROM `private` WHERE `to` = \'' . getid() . '\' AND `id` = \'' . $id . '\';');
        echo '    <span>' . $lang['pmdeleted'] . '</span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
      }
      else
      {
        echo '    <span>' . $lang['pmnotyours'] . '</span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
        echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
      }
    }
  }
  else
  {
    echo theader($lang['pminbox']);
    echo '    <span>' . $lang['pminbox'] . '</span><br /><br />' . "\r\n";

    {
      $query = mysql_query('SELECT COUNT(*) FROM `private` WHERE `to` = \'' . getid() . '\';');
      if(($npms = intval(mysql_result($query, 0))) > 0)
      {
        $ntpp = 10;
        $npages = ceil($npms / $ntpp);

        if($page == 'last')
          $page = $npages;

        $page = intval($page);
        if($page == 0)
          $page = 1;

        if($page > $npages && $page != 1)
          $page = $npages;

        if($page > 1)
          echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;page=1">' . $lang['firstpage'] . '</a></span><br />' . "\r\n";
        if($npages > 1 && $page < $npages)
          echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;page=' . $npages . '">' . $lang['lastpage'] . '</a></span><br />' . "\r\n";

        $limit = ($page - 1) * $ntpp;

        $pms = mysql_query('SELECT * FROM `private` WHERE `to` = \'' . getid() . '\' ORDER BY `date` DESC LIMIT ' . $limit . ', ' . $ntpp . ';');
        if($npms > 0)
        {
          echo '    <div class="left">' . "\r\n";
          while($pm = mysql_fetch_array($pms))
          {
            $id = $pm['id'];
            $from = getusername($pm['from']);
            $date = $pm['date'];
            $read = (bool)$pm['read'];

            if($read)
              $bln = '';
            else
              $bln = '[N]';

            echo '      <div class="pm">' . "\r\n";
	  		    echo '        <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=read&amp;id=' . $id . '">' . $from . '</a> (' . date('d/m/Y, H:i:s', $date) . ')' . $bln . '</span><br />' . "\r\n";
            echo '      </div>' . "\r\n";
          }
	  		  echo '    </div>' . "\r\n";
        }

        if($page > 1)
        {
          $bp = $page - 1;
          $bl = '<a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;page=' . $bp . '">&lt; ' . $lang['backward'] . '</a>';
        }
        else
          $bl = '&lt; ' . $lang['backward'];

        if($page < $npages)
        {
          $fp = $page + 1;
          $fl = ' | <a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;page=' . $fp . '">' . $lang['forward'] . ' &gt;</a>';
        }
        else
          $fl = ' | ' . $lang['forward'] . ' &gt;';

        echo '    </div>' . "\r\n";
        echo '    <span>' . $bl . $fl . '</span><br />' . "\r\n";
      }
      else
      {
        echo '    <span>' . $lang['pmempty'] . '</span><br /><br />' . "\r\n";
      }
    }

    echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=write">' . $lang['pmnew'] . '</a></span><br />' . "\r\n";
    echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=delete&amp;id=all">' . $lang['pmdelete'] . '</a></span><br />' . "\r\n";
    echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
  }

  echo tfooter();
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
