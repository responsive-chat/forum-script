<?php

$language = getarg('lang', 'ka');
if(file_exists($s_scriptpath . '/lang/' . $language . '.php'))
{
  include($s_scriptpath . '/lang/' . $language . '.php');
}
else
{
  include($s_scriptpath . '/lang/ka.php');
}

?>
