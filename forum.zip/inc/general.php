<?php

function getarg($arg, $def = NULL)
{
  if(isset($_REQUEST[$arg]) && !empty($_REQUEST[$arg]))
  {
    return trim(clean($_REQUEST[$arg]));
  }
  else
  {
    return $def;
  }
}

?>
