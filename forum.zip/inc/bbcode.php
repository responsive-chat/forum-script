<?php

function bbcode($string)
{
  $string = preg_replace('#\[url](.*)\[\/url\]#Ui', '<a href="\\1" target="_blank">\\1</a>', $string);
  $string = preg_replace('#\[img](.*)\[\/img\]#Ui', '<img src="\\1" style="width:100%;" alt="\\1" \/>', $string);
  $string = preg_replace('#\[url\=(.*)\](.*)\[/url\]#Ui', '<a href="\\1" target="_blank">\\2</a>', $string);
  $string = preg_replace('#\[img\=(.*)\](.*)\[/img\]#Ui', '<img src="\\1" style="width:100%;" alt="\\2" \/>', $string);
  $string = preg_replace('#\[youtube](.*)\[\/youtube\]#Ui', '<iframe width="300" height="220" src="https://www.youtube.com/embed/\\1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>', $string);
  $string = preg_replace('#\[u](.*)\[\/u\]#Ui', '<u>\\1</u>', $string);
  $string = preg_replace('#\[i](.*)\[\/i\]#Ui', '<i>\\1</i>', $string);
  $string = preg_replace('#\[b](.*)\[\/b\]#Ui', '<b>\\1</b>', $string);
  $string = preg_replace('#\[big](.*)\[\/big\]#Ui', '<big>\\1</big>', $string);
  $string = preg_replace('#\[small](.*)\[\/small\]#Ui', '<small>\\1</small>', $string);
  $string = preg_replace('#\[red](.*)\[\/red\]#Ui', '<font color="Red">\\1</font>', $string);
  $string = preg_replace('#\[green](.*)\[\/green\]#Ui', '<font color="Green">\\1</font>', $string);
  $string = preg_replace('#\[blue](.*)\[\/blue\]#Ui', '<font color="Blue">\\1</font>', $string);
  $string = preg_replace('#\[color\=(\#[0-9A-F]{3,6}|[a-z\-]+)\](.*)\[/color\]#Ui', '<font color="\\1">\\2</font>', $string);
  $string = preg_replace('#\[code](.*)\[\/code\]#Ui', '<div class="code"><code>\\1</code></div>', $string);
  $string = preg_replace('#\[spoiler](.*)\[\/spoiler\]#Ui', '<details><summary>სპოილერის ნახვა</summary>\\1</details>', $string);
  return $string;
}

?>
