<?php

function theader($title = NULL)
{
  global $s_sitename, $s_siteurl;

  if(getid() == NULL)
    $tuid = 0;
  else
    $tuid = getid();

  if($title == NULL)
    setonline($tuid, '???');
  else
    setonline($tuid, $title);

  if($title == NULL)
    $title = $s_sitename;
  else
    $title = $s_sitename . ' - ' . $title;

  $string = '<?xml version="1.0" encoding="utf-8"?>' . "\r\n";
  $string .= '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">' . "\r\n";
  $string .= '<html xmlns="http://www.w3.org/1999/xhtml">' . "\r\n";
  $string .= '<head>' . "\r\n";
  $string .= '  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />' . "\r\n";
  $string .= '  <title>' . $title . '</title> <meta name="description" content="ქართული მაღალინტელექტუალური ინტერნეტ ფორუმი."> <meta name="viewport" content="width=device-width, initial-scale=1.0">' . "\r\n";
  $string .= '  <link rel="stylesheet" href="' . $s_siteurl . '/style.css" type="text/css" />' . "\r\n";
  $string .= '</head>' . "\r\n";
  $string .= '<body>' . "\r\n";
	$string .= '  <a href="/index.php"><img src="logo.png" alt="ფორუმი"></a><div class="header">' . $s_sitename . '</div>' . "\r\n";
  $string .= '  <div class="content">' . "\r\n";
  return $string;
}

function tfooter()
{
  global $s_sitename, $s_siteurl, $language;
  if($language == 'ka')
  {
    $srlink = 'ქართული';

    $enlink = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $enlink = strpos($enlink, 'lang=ka') ? $enlink : $enlink . '&lang=ka';
    $enlink = str_replace('lang=ka', 'lang=en', $enlink);
    $enlink = str_replace('&', '&amp;', $enlink);
    $enlink = str_replace('?&amp;', '?', $enlink);
    $enlink = '<a href="' . $s_siteurl . $enlink . '">English</a>';
    
    $rulink = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $rulink = strpos($rulink, 'lang=ka') ? $rulink : $rulink . '&lang=ka';
    $rulink = str_replace('lang=ka', 'lang=ru', $rulink);
    $rulink = str_replace('&', '&amp;', $rulink);
    $rulink = str_replace('?&amp;', '?', $rulink);
    $rulink = '<a href="' . $s_siteurl . $rulink . '">Русский</a>';
  }
  elseif($language == 'ru')
  {
    $rulink = 'Русский';

    $enlink = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $enlink = strpos($enlink, 'lang=ru') ? $enlink : $enlink . '&lang=ru';
    $enlink = str_replace('lang=ru', 'lang=en', $enlink);
    $enlink = str_replace('&', '&amp;', $enlink);
    $enlink = str_replace('?&amp;', '?', $enlink);
    $enlink = '<a href="' . $s_siteurl . $enlink . '">English</a>';

    $srlink = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $srlink = strpos($srlink, 'lang=ru') ? $srlink : $srlink . '&lang=ru';
    $srlink = str_replace('lang=ru', 'lang=ka', $srlink);
    $srlink = str_replace('&', '&amp;', $srlink);
    $srlink = str_replace('?&amp;', '?', $srlink);
    $srlink = '<a href="' . $s_siteurl . $srlink . '">ქართული</a>';
  }
  else
  {
    $enlink = 'English';

    $srlink = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $srlink = strpos($srlink, 'lang=en') ? $srlink : $srlink . '&lang=en';
    $srlink = str_replace('lang=en', 'lang=ka', $srlink);
    $srlink = str_replace('&', '&amp;', $srlink);
    $srlink = str_replace('?&amp;', '?', $srlink);
    $srlink = '<a href="' . $s_siteurl . $srlink . '">ქართული</a>';
    
    $rulink = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $rulink = strpos($rulink, 'lang=en') ? $rulink : $rulink . '&lang=en';
    $rulink = str_replace('lang=en', 'lang=ru', $rulink);
    $rulink = str_replace('&', '&amp;', $rulink);
    $rulink = str_replace('?&amp;', '?', $rulink);
    $rulink = '<a href="' . $s_siteurl . $rulink . '">Русский</a>';
  }
  $string = '    <span>' . $srlink . ' | ' . $rulink . ' | ' . $enlink . '</span><br />' . "\r\n";
  $string .= '  </div>' . "\r\n";
  $string .= '  <div class="footer">&copy;' . date('Y', time()) . ' <a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $s_sitename . '</a>.</div><br><!-- BOOM.GE COUNTER CODE START --><a href="http://top.boom.ge/index.php?id=61271" target="_blank"><img src="http://links.boom.ge/nojs.php?id=61271" border="0" alt="მთვლელი"></a><!-- BOOM.GE COUNTER CODE END -->' . "\r\n";
  $string .= '</body>' . "\r\n";
  $string .= '</html>' . "\r\n";
  return $string;
}

function tloginbox()
{
  global $s_siteurl, $lang, $language;
  $string = '    <div class="box">' . "\r\n";
  $string .= '      <form method="get" action="' . $s_siteurl . '/login.php">' . "\r\n";
  $string .= '        <input type="hidden" name="lang" value="' . $language . '" />' . "\r\n";
	$string .= '        <span>' . $lang['username'] . ': </span><br />' . "\r\n";
	$string .= '        <input type="text" name="username" /><br />' . "\r\n";
	$string .= '        <span>' . $lang['password'] . ': </span><br />' . "\r\n";
	$string .= '        <input type="password" name="password" /><br />' . "\r\n";
	$string .= '        <input type="submit" value="' . $lang['login'] . '" />&nbsp;<input type="reset" value="' . $lang['reset'] . '" /><br /><br />' . "\r\n";
	$string .= '      </form>' . "\r\n";
	$string .= '      <small><a href="' . $s_siteurl . '/recover.php?lang=' . $language . '">' . $lang['lostpassword'] . '?</a></small>' . "\r\n";
	$string .= '    </div>' . "\r\n";
	return $string;
}

function tregisterbox($code)
{
  global $s_siteurl, $lang, $language;
  $string = '    <div class="box">' . "\r\n";
  $string .= '      <form method="post" action="' . $s_siteurl . '/register.php?lang=' . $language . '">' . "\r\n";
	$string .= '        <input type="hidden" name="code" value="' . $code . '" />' . "\r\n";
	$string .= '        <span>' . $lang['username'] . ': </span><br />' . "\r\n";
	$string .= '        <input type="text" name="username" /><br />' . "\r\n";
	$string .= '        <span>' . $lang['password'] . ': </span><br />' . "\r\n";
	$string .= '        <input type="password" name="password" /><br />' . "\r\n";
  $string .= '        <span>' . $lang['email'] . ': </span><br />' . "\r\n";
	$string .= '        <input type="text" name="email" /><br />' . "\r\n";
	$string .= '        <input type="submit" value="' . $lang['register'] . '" />&nbsp;<input type="reset" value="' . $lang['reset'] . '" />' . "\r\n";
	$string .= '      </form>' . "\r\n";
	$string .= '    </div>' . "\r\n";
	return $string;
}

function tcodebox()
{
  global $s_siteurl, $lang, $language;
  $string = '    <div class="box">' . "\r\n";
  $string .= '      <form method="get" action="' . $s_siteurl . '/register.php">' . "\r\n";
  $string .= '        <input type="hidden" name="lang" value="' . $language . '" />' . "\r\n";
	$string .= '        <span>' . $lang['invitecode'] . ': </span><br />' . "\r\n";
	$string .= '        <input type="text" name="code" /><br />' . "\r\n";
	$string .= '        <input type="submit" value="' . $lang['continue'] . '" />&nbsp;<input type="reset" value="' . $lang['reset'] . '" />' . "\r\n";
	$string .= '      </form>' . "\r\n";
	$string .= '    </div>' . "\r\n";
	return $string;
}

function trecoverbox()
{
  global $s_siteurl, $lang, $language;
  $string = '    <div class="box">' . "\r\n";
  $string .= '      <form method="post" action="' . $s_siteurl . '/recover.php?lang=' . $language . '">' . "\r\n";
	$string .= '        <span>' . $lang['email'] . ': </span><br />' . "\r\n";
	$string .= '        <input type="text" name="email" /><br />' . "\r\n";
	$string .= '        <input type="submit" value="' . $lang['recover'] . '" />&nbsp;<input type="reset" value="' . $lang['reset'] . '" />' . "\r\n";
	$string .= '      </form>' . "\r\n";
	$string .= '    </div>' . "\r\n";
	return $string;
}

?>
