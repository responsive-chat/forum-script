<?php

@session_start();
$u_username = isset($_SESSION['username']) ? (empty($_SESSION['username']) ? NULL : $_SESSION['username']) : NULL;
$u_password = isset($_SESSION['password']) ? (empty($_SESSION['password']) ? NULL : $_SESSION['password']) : NULL;
$u_time = isset($_SESSION['time']) ? (empty($_SESSION['time']) ? NULL : $_SESSION['time']) : NULL;

?>
