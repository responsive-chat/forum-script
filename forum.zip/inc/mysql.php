<?php

if($s_sql == NULL)
  $s_sql = @mysql_pconnect($s_sqlhost, $s_sqluser, $s_sqlpass) or die('Maintenance');

if($s_db == NULL && $s_sql != NULL)
  $s_db = @mysql_select_db($s_sqlbase, $s_sql) or die('Maintenance');

if($s_sql != NULL && $s_db != NULL)
  @mysql_query('SET NAMES `utf8`;');
?>