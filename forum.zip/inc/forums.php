<?php

function listforums()
{
  global $s_siteurl, $lang, $language;
  echo '    <div class="left">' . "\r\n";
  echo '      <div class="forums">' . "\r\n";
  echo '        <div class="center"><span>' . $lang['forums'] . '</span></div>' . "\r\n";
  $forums = mysql_query("SELECT * FROM `forums` ORDER BY `position` ASC;");
	if(mysql_num_rows($forums) > 0)
	{
	  while($forum = mysql_fetch_array($forums))
		{
		  $id = clean($forum['id']);
		  $title = clean($forum['title']);
			$description = clean($forum['description']);
      $description = bbcode($description);
      $description = smile($description);
			$query = mysql_query('SELECT COUNT(*) FROM `threads` WHERE `forum` = \'' . $id . '\';');
			$result = mysql_fetch_array($query);
			$threadsCount = intval($result[0]);

      if(checkadmin())
      {
        $edl = ' <a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=edit&amp;what=forum&amp;id=' . $id . '">[' . $lang['redact'] . ']</a>';
        $dll = ' <a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=delete&amp;what=forum&amp;id=' . $id . '"></a>';
      }
      else
      {
        $edl = '';
        $dll = '';
      }

			echo '        <span><a href="' . $s_siteurl . '/forum.php?lang=' . $language . '&amp;id=' . $id . '">' . $title . ' (' . $threadsCount . ')</a>' . $edl . $dll . '</span><br />' . "\r\n";
			echo '        <span>' . $description . '</span><br />' . "\r\n";
		}
	}
	else
	{
	  echo '      <span>' . $lang['noforums'] . '</span><br />' . "\r\n";
	}

  if(checkadmin())
    echo '        <div class="center"><span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '&amp;do=new&amp;what=forum">[' . $lang['newforum'] . ']</a></span></div>' . "\r\n";
  echo '      </div>' . "\r\n";
	echo '    </div>' . "\r\n";
	return;
}

?>
