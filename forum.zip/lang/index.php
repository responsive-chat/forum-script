<?php

// Криме / Krime

header('Location: ../');

?>
