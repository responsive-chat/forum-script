<?php

header('Location: ../');

?>
