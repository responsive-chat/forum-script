<?php

include('common.php');

if(islogged())
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}
else
{
  echo theader();

  if($s_inviteonly)
  {
    if($devel)
      echo '    <span>' . $lang['develnote'] . ' <b>' . $s_megacode . '</b></span><br /><br />' . "\r\n";

    $code = getarg('code');
    if($code == $s_megacode)
	  {
	    $newcode = clean(getcode());
		  @mysql_query('INSERT INTO `invites` VALUES(\'0\', \'1\', \'' . $newcode . '\');');
      echo '    <span>' . $lang['uberaccepted'] . '</span><br />' . "\r\n";
	    echo '    <form method="get" action="' . $s_siteurl . '/register.php">' . "\r\n";
      echo '      <input type="hidden" name="lang" value="' . $language . '" />' . "\r\n";
	  	echo '      <input type="hidden" name="code" value="' . $newcode . '" />' . "\r\n";
	  	echo '      <input type="submit" value="' . $lang['continue'] . '" /><br /><br />' . "\r\n";
	  	echo '    </form>' . "\r\n";
  	}
	  elseif($code == NULL)
	  {
      echo '    <span>' . $lang['inviteonly'] . '</span><br /><br />' . "\r\n";
	  	echo tcodebox();
	    echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
  	}
	  elseif(!checkinvite($code))
  	{
      echo '    <span>' . $lang['invalidinvite'] . '</span><br />' . "\r\n";
	    echo '    <span><a href="' . $s_siteurl . '/register.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
	  }
  	else
    {
	    $username = getarg('username');
	    $password = getarg('password');
	    $email = getarg('email');
	  	if($username != NULL && $password != NULL && $email != NULL)
	  	{
	  	  $errtext = '';
	  	  if(checkusername($username))
	  		  $errtext .= '    <span>' . $lang['userexists'] . '</span><br />' . "\r\n";
		    if(!checkemail($email))
	  		  $errtext .= '    <span>' . $lang['invalidemail'] . '</span><br />' . "\r\n";
	  		if(strlen($password) < 5)
	  		  $errtext .= '    <span>' . $lang['invalidpassword'] . '</span><br />' . "\r\n";

        $query = mysql_query('SELECT * FROM `users` WHERE `email` = \'' . clean($email) . '\';');
        if(mysql_num_rows($query) > 0)
          $errtext .= '    <span>' . $lang['emailtaken'] . '</span><br />' . "\r\n";
			
		  	if($errtext != '')
		  	{
		  	  echo $errtext;
		  		echo '    <span><a href="' . $s_siteurl . '/register.php?lang=' . $language . '&amp;code=' . $code . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
		  	}
		  	else
		  	{
		  	  if(adduser($username, $password, $email))
		  		{
		  		  $msub = $lang['regat'] . ' ' . $s_sitename;
		  		  $mmsg = $lang['username'] . ': ' . clean($username) . "\r\n" . $lang['password'] . ': ' . clean($password) . "\r\n" . $s_siteurl . '/' . "\r\n";
			  	  @mail($email, $msub, $mmsg, "From: $s_email <$s_email>\r\n");
			  		removeinvite($code);
            echo '    <span>' . $lang['regsuccess'] . '</span><br />' . "\r\n";
			  		echo '    <span>' . $lang['username'] . ': ' . clean($username) . '</span><br />' . "\r\n";
		  			echo '    <span>' . $lang['password'] . ': ' . clean($password) . '</span><br />' . "\r\n";
	          echo '    <span><a href="' . $s_siteurl . '/login.php?lang=' . $language . '&amp;username=' . clean($username) . '&amp;password=' . clean($password) . '">' . $lang['continue'] . '</a></span><br /><br />' . "\r\n";
		  		}
	  		}
	  	}
	  	else
	  	{
        echo '    <span>' . $lang['reginfo'][1] . '</span><br />' . "\r\n";
        echo '    <span>' . $lang['reginfo'][2] . '</span><br /><br />' . "\r\n";
	      echo tregisterbox($code);
	      echo '    <br />' . "\r\n";
	      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
	  	}
	  }
  }
  else
  {
    $username = getarg('username');
	  $password = getarg('password');
	  $email = getarg('email');
	  if($username != NULL && $password != NULL && $email != NULL)
	  {
	  	$errtext = '';
	  	if(checkusername($username))
	 	  $errtext .= '    <span>' . $lang['userexists'] . '</span><br />' . "\r\n";
      if(!checkemail($email))
  		  $errtext .= '    <span>' . $lang['invalidemail'] . '</span><br />' . "\r\n";
  		if(strlen($password) < 5)
  		  $errtext .= '    <span>' . $lang['invalidpassword'] . '</span><br />' . "\r\n";

      $query = mysql_query('SELECT * FROM `users` WHERE `email` = \'' . clean($email) . '\';');
      if(mysql_num_rows($query) > 0)
        $errtext .= '    <span>' . $lang['emailtaken'] . '</span><br />' . "\r\n";
			
	  	if($errtext != '')
	  	{
		error_reporting(0);
    	  echo $errtext;
	  		echo '    <span><a href="' . $s_siteurl . '/register.php?lang=' . $language . '&amp;code=' . $code . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
	  	}
	  	else
	  	{
		    if(adduser($username, $password, $email))
		  	{
		  		$msub = $lang['regat'] . ' ' . $s_sitename;
		  		$mmsg = $lang['username'] . ': ' . clean($username) . "\r\n" . $lang['password'] . ': ' . clean($password) . "\r\n" . $s_siteurl . '/' . "\r\n";
			  	@mail($email, $msub, $mmsg, "From: $s_email <$s_email>\r\n");
			  	removeinvite($code);
          echo '    <span>' . $lang['regsuccess'] . '</span><br />' . "\r\n";
			  	echo '    <span>' . $lang['username'] . ': ' . clean($username) . '</span><br />' . "\r\n";
		  		echo '    <span>' . $lang['password'] . ': ' . clean($password) . '</span><br />' . "\r\n";
	        echo '    <span><a href="' . $s_siteurl . '/login.php?lang=' . $language . '&amp;username=' . clean($username) . '&amp;password=' . clean($password) . '">' . $lang['continue'] . '</a></span><br /><br />' . "\r\n";
		  	}
	  	}
	  }
	  else
	  {
      echo '    <span>' . $lang['reginfo'][1] . '</span><br />' . "\r\n";
      echo '    <span>' . $lang['reginfo'][2] . '</span><br /><br />' . "\r\n";
	    error_reporting(0);
		echo tregisterbox($code);
	    echo '    <br />' . "\r\n";
	    echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
	  }
  }

  echo tfooter();
}

exit();

?>
