<?php

include('common.php');

$gaid = getarg('id', 0);
$do = getarg('do');

if(islogged())
{
  if($gaid == 0)
    $gaid = getid();

  if($do == 'ban')
  {
    if(checkmod())
    {
      $uusername = getusername($gaid);
      if(!checkadmin($uusername))
      {
        if(checkbanned($uusername))
        {
          @mysql_query('UPDATE `users` SET `banned` = \'0\', `bantime` = \'0\' WHERE `id` = \'' . $gaid . '\';');
        }
        else
        {
          @mysql_query('UPDATE `users` SET `banned` = \'1\', `bantime` = \'' . time() . '\' WHERE `id` = \'' . $gaid . '\';');
        }
      }
    }

    header('Location: ' . $s_siteurl . '/profile.php?lang=' . $language . '&id=' . $gaid);
  }
  elseif($do == 'delete')
  {
    $query = mysql_query('SELECT * FROM `users` WHERE `id` = \'' . $gaid . '\';');
    if(mysql_num_rows($query) > 0 && !checkadmin(getusername($gaid)))
    {
      if(checkadmin())
      {
        @mysql_query('DELETE FROM `invites` WHERE `user` = \'' . $gaid . '\';');
        @mysql_query('DELETE FROM `online` WHERE `user` = \'' . $gaid . '\';');
        @mysql_query('UPDATE `posts` SET `poster` = \'1\' WHERE `poster` = \'' . $gaid . '\';');
        @mysql_query('DELETE FROM `private` WHERE `to` = \'' . $gaid . '\';');
        @mysql_query('UPDATE `private` SET `from` = \'1\' WHERE `from` = \'' . $gaid . '\';');
        @mysql_query('DELETE FROM `recover` WHERE `user` = \'' . $gaid . '\';');
        @mysql_query('UPDATE `shoutbox` SET `user` = \'1\' WHERE `user` = \'' . $gaid . '\';');
        @mysql_query('UPDATE `threads` SET `poster` = \'1\' WHERE `poster` = \'' . $gaid . '\';');
        @mysql_query('DELETE FROM `users` WHERE `id` = \'' . $gaid . '\';');
      }
    }

    header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
  }
  elseif($do == 'edit')
  {
    $query = mysql_query('SELECT * FROM `users` WHERE `id` = \'' . $gaid . '\';');
    if(mysql_num_rows($query) > 0)
    {
      if($gaid == getid() || checkadmin())
      {
        $result = mysql_fetch_array($query);
        if(isset($_POST['email']) && !empty($_POST['email']))
        {
          $email = clean($_POST['email']);
          @mysql_query('UPDATE `users` SET `email` = \'' . $email . '\' WHERE `id` = \'' . $gaid . '\';');
          if(checkadmin())
          {
            $username = clean($_POST['username']);
            $status = clean($_POST['status']);
            if(intval($gaid) != 1)
            {
              @mysql_query('UPDATE `users` SET `username` = \'' . $username . '\', `status` = \'' . $status . '\' WHERE `id` = \'' . $gaid . '\';');
            }
            else
            {
              if(intval(getid()) == 1)
              {
                @mysql_query('UPDATE `users` SET `username` = \'' . $username . '\', `status` = \'' . $status . '\' WHERE `id` = \'' . $gaid . '\';');
              }
            }
          }
          $oldpassword = isset($_POST['oldpassword']) ? (empty($_POST['oldpassword']) ? '' : clean($_POST['oldpassword'])) : '';
          $newpassword = isset($_POST['newpassword']) ? (empty($_POST['newpassword']) ? '' : clean($_POST['newpassword'])) : '';
          if($newpassword != '')
          {
            if(checkadmin())
            {
              if($gaid == getid())
                  $_SESSION['password'] = $newpassword;
                @mysql_query('UPDATE `users` SET `password` = \'' . md5(md5($newpassword)) . '\' WHERE `id` = \'' . $gaid . '\';');
            }
            else
            {
              if($oldpassword != '')
              {
                $oldpassword = md5(md5($oldpassword));
                if($oldpassword == $result['password'])
                {
                  if($gaid == getid())
                    $_SESSION['password'] = $newpassword;
                  @mysql_query('UPDATE `users` SET `password` = \'' . md5(md5($newpassword)) . '\' WHERE `id` = \'' . $gaid . '\';');
                }
              }
            }
          }

          header('Location: ' . $s_siteurl . '/profile.php?lang=' . $language . '&id=' . $gaid);
        }
        else
        {
          echo theader($lang['editprofile']);
          echo '    <span>' . $lang['editprofile'] . '</span><br /><br />' . "\r\n";
          echo '    <form method="post" action="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $gaid . '&amp;do=edit">' . "\r\n";
          if(checkadmin())
          {
            echo '      <span>' . $lang['username'] . ':</span><br />' . "\r\n";
            echo '      <input type="text" name="username" value="' . $result['username'] . '" /><br /><br />' . "\r\n";
            echo '      <span>' . $lang['status']['status'] . ':</span><br />' . "\r\n";
            echo '      <select name="status">' . "\r\n";
            $sadm = ''; 
            $smod = ''; 
            $susr = '';
            if(intval($result['status']) >= 3)
              $sadm = ' selected="selected"';
            elseif(intval($result['status']) == 2)
              $smod = ' selected="selected"';
            elseif(intval($result['status']) == 1)
              $susr = ' selected="selected"';
            echo '        <option value="1"' . $susr . '>' . $lang['status']['user'] . '</option>' . "\r\n";
            echo '        <option value="2"' . $smod . '>' . $lang['status']['mod'] . '</option>' . "\r\n";
            echo '        <option value="3"' . $sadm . '>' . $lang['status']['admin'] . '</option>' . "\r\n";
            echo '      </select><br /><br />' . "\r\n";
          }
          echo '      <span>' . $lang['email'] . ':</span><br />' . "\r\n";
          echo '      <input type="text" name="email" value="' . $result['email'] . '" /><br /><br />' . "\r\n";
          if($gaid == getid())
          {
            echo '      <span>' . $lang['oldpassword'] . ':</span><br />' . "\r\n";
            echo '      <input type="password" name="oldpassword" /><br />' . "\r\n";
          }
          echo '      <span>' . $lang['newpassword'] . ':</span><br />' . "\r\n";
          echo '      <input type="password" name="newpassword" /><br />' . "\r\n";
          echo '      <input type="submit" value="' . $lang['edit'] . '" /><br />' . "\r\n";
          echo '    </form>' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $gaid . '">' . $lang['back'] . '</a></span><br />' . "\r\n";
          echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['main'] . '</a></span><br /><br />' . "\r\n";
        }
      }
      else
      {
        header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
      }
    }
    else
    {
      header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
    }
  }
  else
  {
    if($gaid == getid())
    {
      echo theader($lang['myprofile']);
    }
    else
    {
      echo theader($lang['profile'] . ' / ' . getusername($gaid));
    }

    $query = mysql_query('SELECT * FROM `users` WHERE `id` = \'' . $gaid . '\';');
    if(mysql_num_rows($query) > 0)
    {
      $result = mysql_fetch_array($query);
      $pusername = clean($result['username']);
      $email = clean($result['email']);
      $date = clean($result['date']);
      $level = intval(clean($result['status']));
      $status = formatstatus($level, $gaid);
      if(intval(clean($result['banned'])) > 0)
        $status = $lang['status']['banned'];


      $useragent = $result['useragent'];
      $userip = $result['userip'];

      $query = mysql_query('SELECT COUNT(*) FROM `threads` WHERE `poster` = \'' . $gaid . '\';');
      $result = mysql_fetch_array($query);
      $threads = intval($result[0]);
      $query = mysql_query('SELECT COUNT(*) FROM `posts` WHERE `poster` = \'' . $gaid . '\';');
      $result = mysql_fetch_array($query);
      $posts = intval($result[0]);
      $query = mysql_query('SELECT COUNT(*) FROM `shoutbox` WHERE `user` = \'' . $gaid . '\';');
      $result = mysql_fetch_array($query);
      $shouts = intval($result[0]);
      $query = mysql_query('SELECT COUNT(*) FROM `private` WHERE `to` = \'' . $gaid . '\';');
      $result = mysql_fetch_array($query);
      $inpms = intval($result[0]);
      $query = mysql_query('SELECT COUNT(*) FROM `private` WHERE `from` = \'' . $gaid . '\';');
      $result = mysql_fetch_array($query);
      $outpms = intval($result[0]);

      echo '    <span><a href="' . $s_siteurl . '/private.php?lang=' . $language . '&amp;do=write&amp;to=' . $pusername . '">' . $lang['pmsend'] . '</a></span><br /><br />' . "\r\n";
      echo '    <div class="left">' . "\r\n";
      echo '      <span>' . $lang['username'] . ': ' . $pusername . '</span><br />' . "\r\n";
      echo '      <span>' . $lang['status']['status'] . ': ' . $status . '</span><br />' . "\r\n";
      echo '      <span>' . $lang['email'] . ': ' . $email . '</span><br />' . "\r\n";
      echo '      <span>' . $lang['numthreads'] . ': ' . $threads . '</span><br />' . "\r\n";
      echo '      <span>' . $lang['posts'] . ': ' . $posts . '</span><br />' . "\r\n";
      echo '      <span>' . $lang['shouts'] . ': ' . $shouts . '</span><br />' . "\r\n";
      echo '      <span>' . $lang['numpms'] . ': ' . $inpms . ' / ' . $outpms . '</span><br />' . "\r\n";
      echo '      <span>' . $lang['regdate'] . ': ' . date('d/m/Y, H:i:s', $date) . '</span><br />';
      if(checkmod())
      {
        echo "\r\n";
        echo '      <span>' . $lang['useragent'] . ': ' . $useragent . '</span><br />' . "\r\n";
        echo '      <span>' . $lang['userip'] . ': ' . $userip . '</span><br />' . "\r\n";
        if(checkbanned($pusername))
          echo '      <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $gaid . '&amp;do=ban">' . $lang['unban'] . '</a>';
        else
          echo '      <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $gaid . '&amp;do=ban">' . $lang['ban'] . '</a>';
        if(!checkadmin())
          echo '</span><br />';
      }
      if(checkadmin())
        echo ' | <a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $gaid . '&amp;do=delete">' . $lang['delete'] . '</a></span><br />';

      echo "\r\n";
      echo '    </div>' . "\r\n";
      if($gaid == getid() || checkadmin())
        echo '    <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $gaid . '&amp;do=edit">' . $lang['edit'] . '</a></span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
    }
    else
    {
      echo '    <span>' . $lang['usernotexist'] . '</span><br />' . "\r\n";
      echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
    }
  }

  echo tfooter();
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
