<?php

include('settings.php');
include($s_scriptpath . '/inc/session.php');
require($s_scriptpath . '/inc/mysql.php');
require($s_scriptpath . '/inc/security.php');
include($s_scriptpath . '/inc/general.php');
require($s_scriptpath . '/inc/language.php');
require($s_scriptpath . '/inc/auth.php');
require($s_scriptpath . '/inc/template.php');
require($s_scriptpath . '/inc/bbcode.php');
require($s_scriptpath . '/inc/smiles.php');
require($s_scriptpath . '/inc/forums.php');

if(get_magic_quotes_gpc())
{
  $in = array(&$_GET, &$_POST, &$_COOKIE, &$_SESSION);
  while(list($k, $v) = each($in))
  {
    foreach($v as $key => $val)
    {
      if(!is_array($val))
      {
        $in[$k][$key] = stripslashes($val);
        continue;
      }

      $in[] = &$in[$k][$key];
    }
  }

  unset($in);

  if(!empty($_FILES))
  {
    foreach($_FILES as $k => $v)
    {
      $_FILES[$k]['name'] = stripslashes((string)$v['name']);
    }
  }
}

if(checkbanned())
{
  header('Location: ' . $s_bannedurl);
  exit();
}

if(islogged())
{
  if(checkbanned($u_username))
  {
    header('Location: ' . $s_bannedurl);
    exit();
  }
}

$time = time();
$timeout = $time - 300;
@mysql_query('DELETE FROM `online` WHERE `time` < \'' . $timeout . '\';');

?>
