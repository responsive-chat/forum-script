<?php

include('common.php');

$do = getarg('do', '');
$page = intval(getarg('page', 1));

if(islogged())
{
  if($do == 'banned')
    $astring = ' WHERE `banned` = \'1\'';
  elseif($do == 'mods')
    $astring = ' WHERE `status` = \'2\'';
  elseif($do == 'admins')
    $astring = ' WHERE `status` = \'3\'';
  else
    $astring = '';

  if($astring != '')
    $dos = '&amp;do=' . $do . '&amp;';
  else
    $dos = '';

  $alink = '<a href="' . $s_siteurl . '/users.php?lang=' . $language . '&amp;do=admins">' . $lang['uadmins'] . '</a>';
  $mlink = '<a href="' . $s_siteurl . '/users.php?lang=' . $language . '&amp;do=mods">' . $lang['umods'] . '</a>';
  $blink = '<a href="' . $s_siteurl . '/users.php?lang=' . $language . '&amp;do=banned">' . $lang['ubanned'] . '</a>';
  $ulink = '<a href="' . $s_siteurl . '/users.php?lang=' . $language . '">' . $lang['lusers'] . '</a>';

  if($do == 'admins')
    $alink = $lang['uadmins'];
  elseif($do == 'mods')
    $mlink = $lang['umods'];
  elseif($do == 'banned')
    $blink = $lang['ubanned'];
  else
    $ulink = $lang['lusers'];

  echo theader($lang['lusers']);
  echo '    <span>' . $alink . ' - ' . $mlink . '</span><br />' . "\r\n";
  echo '    <span>' . $ulink . ' - ' . $blink . '</span><br /><br />' . "\r\n";

  $query = mysql_query('SELECT COUNT(*) FROM `users`' . $astring . ';');
  $nusers = mysql_result($query, 0);
  $upp = 10;
  $npages = ceil($nusers / $upp);

  if($page > $npages && $page != 1)
    $page = $npages;

  $limit = ($page - 1) * $upp;
  $users = mysql_query('SELECT * FROM `users`' . $astring . ' ORDER BY `date` ASC LIMIT ' . $limit . ', ' . $upp . ';');
  if(mysql_num_rows($users) > 0)
  {
    echo '    <div class="left">' . "\r\n";
    while($user = mysql_fetch_array($users))
    {
      $uid = intval($user['id']);
      $uusername = $user['username'];
      if($user['banned'] > 0)
        $ustatus = $lang['status']['banned'];
      else
        $ustatus = formatstatus(intval($user['status']), intval($user['id']));
      echo '      <span><a href="' . $s_siteurl . '/profile.php?lang=' . $language . '&amp;id=' . $uid . '">' . $uusername . '</a> (' . $ustatus . ')</span><br />' . "\r\n";
    }
    echo '    </div>' . "\r\n";

    if($page > 1)
    {
      $bp = $page - 1;
      $bl = '<a href="' . $s_siteurl . '/users.php?lang=' . $language . $dos . '&amp;page=' . $bp . '">&lt; ' . $lang['backward'] . '</a>';
    }
    else
      $bl = '&lt; ' . $lang['backward'];

    if($page < $npages)
    {
      $fp = $page + 1;
      $fl = ' | <a href="' . $s_siteurl . '/users.php?lang=' . $language . $dos . '&amp;page=' . $fp . '">' . $lang['forward'] . ' &gt;</a>';
    }
    else
      $fl = ' | ' . $lang['forward'] . ' &gt;';

    echo '    <span>' . $bl . $fl . '</span><br />' . "\r\n";
    echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
  }
  else
  {
    echo '    <span>' . $lang['nousers'] . '</span><br />' . "\r\n";
    echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
  }

  echo tfooter();
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
