<?php

include('common.php');

if(islogged())
{
  echo theader($lang['statistics']);
  echo '    <span>' . $lang['statistics'] . '</span><br /><br />' . "\r\n";
  echo '    <div class="left">' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `users`;');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['numusers'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `private`;');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['numprivate'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `forums`;');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['numforums'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `threads`;');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['snumthreads'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `posts`;');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['numposts'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `shoutbox`;');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['shouts'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `users` WHERE `status` = \'2\';');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['nummods'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `users` WHERE `status` = \'3\';');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['numadmins'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  $query = mysql_query('SELECT COUNT(*) FROM `users` WHERE `banned` = \'1\';');
  $result = intval(mysql_result($query, 0));
  echo '      <span>' . $lang['numbanned'] . ': <b>' . $result . '</b></span><br />' . "\r\n";
  echo '    </div>' . "\r\n";
	echo '    <span><a href="' . $s_siteurl . '/index.php?lang=' . $language . '">' . $lang['back'] . '</a></span><br /><br />' . "\r\n";
  echo tfooter();
}
else
{
  header('Location: ' . $s_siteurl . '/index.php?lang=' . $language);
}

exit();

?>
