<?php

@ini_set('register_globals', 'Off');

$devel = TRUE; // is this develop version? if yes, show megacode on registration page
if($devel)
  @ini_set('error_reporting', E_ALL);
else
  @ini_set('error_reporting', E_NONE);

$s_sqlhost = 'localhost'; // server hostname
$s_sqlbase = '1114981'; // database name
$s_sqluser = '1114981'; // username
$s_sqlpass = 'paroli12345'; // password

global $s_sql, $s_db;

$s_sql = ($s_sql == NULL ? NULL : $s_sql);
$s_db = ($s_db == NULL ? NULL : $s_db);

$s_scriptpath = '/home/vhosts/forumi.eu.org'; // path to script, without / on the end
$s_sitename = 'forumi.eu.org'; // site name
$s_siteurl = 'http://forumi.eu.org'; // site url, without / on the end
$s_email = str_replace(' ', '-', strtolower($s_sitename . '@' . str_replace('http://', '', $s_siteurl))); // site email
$s_deflang = 'ka'; // default language, ka/ru/en
$s_megacode = 'hiddencode'; // used for registration without invitation
$s_inviteonly = FALSE;
$s_bannedurl = 'http://forumi.eu.org/'; // where to redirect if banned

?>